package game;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;

import javax.sound.midi.*;
import javax.sound.sampled.*;
import javax.swing.ImageIcon;

import game2D.*;

// Game demonstrates how we can override the GameCore class
// to create our own 'game'. We usually need to implement at
// least 'draw' and 'update' (not including any local event handling)
// to begin the process. You should also add code to the 'init'
// method that will initialise event handlers etc. By default GameCore
// will handle the 'Escape' key to quit the game but you should
// override this with your own event handler.

/**
 * @author David Cairns
 * @author brs00035
 */
@SuppressWarnings("serial")
class Game extends GameCore {
    // Useful game constants
    // 600, 384
    static int screenWidth = 576;
    static int screenHeight = 324;
    ArrayList<Image> backGroundImages = new ArrayList<>();

    static long jumpTime = 200;
    float lift = 0.005f;
    float gravity = 0.0001f;
    boolean canJump = false;
    boolean walkingLeft = false;
    boolean walkingRight = false;
    boolean jumping = false;
    boolean climbing = false;
    boolean falling = true;

    boolean hitSpikes = false;
    boolean goldenKeyGained = false;
    boolean silverKeyGained = false;
    boolean menuState = true;
    boolean gameState = false;
    boolean restartState = false;
    Sprite monsterRed;
    Sprite purpleMonster;
    Animation silverChestOpen;
    Animation goldenChestOpen;
    Animation purpleMonsterIdle;
    Animation purpleMonsterAttack;
    Animation purpleMonsterWalk;
    Animation purpleMonsterWalkRight;
    Animation redMonsterWalkRight;
    Animation redMonsterIdle;
    Animation redMonsterAttack;
    Animation idleAnim;
    Animation walkingAnim;
    Animation jumpingAnim;
    Animation flagAnim;
    Animation climbingAnim;
    Animation redMonsterWalk;
    Animation playerHurt;
    Animation silverKey;
    Animation goldenKey;
    Animation walkingAnimLeft;
    int level = 1;
    int playerLives = 3;
    boolean canClimb = false;
    Sprite silverChest = null;
    Sprite goldenChest = null;
    Sprite player = null;
    Sprite flag = null;
    Sprite silverKeys;
    Sprite goldenKeys;
    Image background;
    boolean startGame = true;
    boolean endGame = false;
    public static int startTime = 0;
    long level1Time = 0;
    long level2Time = 0;
    Sequencer seq;
    TileMap tmap = new TileMap(); // Our tile map, note that we load it in


    long total; // The score will be the total time elapsed since a crash

    /**
     * The obligatory main method that creates an instance of our class and
     * starts it running
     *
     * @param args The list of parameters this program might use (ignored)
     */
    public static void main(String[] args) {

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                timer();
            }
        };
        Timer time = new Timer();
        time.scheduleAtFixedRate(timerTask, 1000, 1000);

        Game gct = new Game();
        gct.setResizable(false);
        gct.init();

        // Start in windowed mode with the given screen height and width
        gct.run(false, screenWidth, screenHeight);

    }

    /**
     * Initialise the class, e.g. set up variables, load images, create
     * animations, register event handlers
     */
    public void init() {


        //plays the best background music
        try {
            playMidi("skyrim.mid");

        } catch (Exception e) {
            System.out.println("error with background music midi file" + e);
        }

        Sprite s; // Temporary reference to a sprite
        idleAnim = new Animation();
        silverKey = new Animation();
        goldenKey = new Animation();
        walkingAnim = new Animation();
        jumpingAnim = new Animation();
        flagAnim = new Animation();
        climbingAnim = new Animation();
        redMonsterIdle = new Animation();
        redMonsterAttack = new Animation();
        purpleMonsterIdle = new Animation();
        purpleMonsterAttack = new Animation();
        purpleMonsterWalkRight = new Animation();
        redMonsterWalkRight = new Animation();
        playerHurt = new Animation();
        redMonsterWalk = new Animation();
        purpleMonsterWalk = new Animation();
        silverChestOpen = new Animation();
        goldenChestOpen = new Animation();
        walkingAnimLeft = new Animation();
        // Load the tile map and print it out so we can check it is valid
        tmap.loadMap("maps", "map.txt");


        //load animations
        redMonsterWalkRight.loadAnimationFromSheet("images/redWalkRight.png", 6, 1, 100);
        purpleMonsterWalkRight.loadAnimationFromSheet("images/WalkRight.png", 4, 1, 100);
        flagAnim.loadAnimationFromSheet("images/Flag.png", 8, 1, 90);
        idleAnim.loadAnimationFromSheet("images/Dude_Monster_Idle_4.png", 4, 1, 100);
        redMonsterWalk.loadAnimationFromSheet("images/redWalk.png", 6, 1, 90);
        walkingAnimLeft.loadAnimationFromSheet("images/Dude_Monster_Walk_6_Left.png", 6, 1, 100);
        walkingAnim.loadAnimationFromSheet("images/Dude_Monster_Walk_6.png", 6, 1, 100);
        jumpingAnim.loadAnimationFromSheet("images/Dude_Monster_Jump_8.png", 8, 1, 100);
        climbingAnim.loadAnimationFromSheet("images/ClimbSprite.png", 4, 1, 90);
        redMonsterIdle.loadAnimationFromSheet("images/redIdle.png", 4, 1, 100);
        redMonsterAttack.loadAnimationFromSheet("images/redAttack.png", 4, 1, 100);
        purpleMonsterIdle.loadAnimationFromSheet("images/Idle.png", 4, 1, 100);
        purpleMonsterAttack.loadAnimationFromSheet("images/Attack.png", 4, 1, 100);
        purpleMonsterWalk.loadAnimationFromSheet("images/Walk.png", 4, 1, 100);
        playerHurt.loadAnimationFromSheet("images/Dude_Monster_Hurt_4.png", 4, 1, 100);
        background = new ImageIcon("images/BackGround1.png").getImage();
        silverChestOpen.loadAnimationFromSheet("images/Silver_Chest_Open.png", 8, 1, 100);
        goldenChestOpen.loadAnimationFromSheet("images/Golden_Chest_Open.png", 8, 1, 100);
        silverKey.loadAnimationFromSheet("images/Silver_Key.png", 12, 1, 100);
        goldenKey.loadAnimationFromSheet("images/Golden_Key.png", 12, 1, 100);


        // Initialise the player with an animation
        player = new Sprite(idleAnim);
        silverChest = new Sprite(silverChestOpen);
        flag = new Sprite(flagAnim);
        silverKeys = new Sprite(silverKey);
        goldenKeys = new Sprite(goldenKey);
        goldenChest = new Sprite((goldenChestOpen));
        monsterRed = new Sprite(redMonsterIdle);
        purpleMonster = new Sprite(purpleMonsterIdle);


        initialiseGame();

        System.out.println(tmap);


        for (int i = 1; i < 9; i++) {
            Image backGroundImg;
            backGroundImg = loadImage("images/" + i + ".png");
            backGroundImages.add(backGroundImg);

        }


    }

    /**
     * starts a timer which is also displayed to console
     */
    public static void timer() {
        startTime++;
        System.out.println("Timer: " + startTime);
    }

    /**
     * loads and plays a wav sound file
     *
     * @param fileName name of the sound file
     */
    public void playSound(String fileName) {
        try {

            File file = new File("sounds/" + fileName);
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            EchoFilterStream filter = new EchoFilterStream(stream);

            //a failed attempt at making a echo filter...
            AudioInputStream f = new AudioInputStream(filter, format, stream.getFrameLength());
            DataLine.Info info = new DataLine.Info(Clip.class, format);

            Clip clip = (Clip) AudioSystem.getLine(info);
            clip.open(stream);
            clip.start();


        } catch (Exception e) {
            System.out.println(e);
        }

    }

    /**
     * plays a midi file, code taken from n6 slides
     *
     * @param fileName midi sound file name
     * @throws Exception
     */
    public void playMidi(String fileName) throws Exception {

        Sequence score = MidiSystem.getSequence(new File("sounds/" + fileName));
        seq = MidiSystem.getSequencer();

        seq.open();
        seq.setSequence(score);
        seq.setTempoFactor(1);
        seq.start();


    }

    /**
     * restarts the game resets player lives
     */
    public void restartGame() throws Exception {

        playerLives = 3;
        seq.stop();
        initialiseGame();
        init();
        gameState = true;
    }

    /**
     * Initialise the game setting positions of sprites
     */
    public void initialiseGame() {


        total = 0;
        level = 1;
        silverKeyGained = false;
        goldenKeyGained = false;
        startGame = true;
        player.setX(64);
        player.setY(290);
        player.setVelocityX(0);
        player.setVelocityY(0);
        player.show();
        startTime = 0;
        level1Time = 0;
        level1Time = 0;
        endGame = false;
        monsterRed.setX(700);
        monsterRed.setY(290);
        monsterRed.show();

        silverChest.setX(700);
        silverChest.setY(160);
        silverChest.setVelocityX(0);
        silverChest.setVelocityY(0);
        silverChest.pauseAnimationAtFrame(1);
        silverChest.show();

        silverKeys.setX(700);
        silverKeys.setY(155);
        silverKeys.setVelocityX(0);
        silverKeys.setVelocityY(0);
        silverKeys.hide();


        flag.setX(800);
        flag.setY(290);
        flag.show();
    }

    /**
     * draws the menu with two rectangle objects to act as the buttons
     *
     * @param g graphics object
     */
    public void drawMenu(Graphics2D g) {

        String msg = String.format("Little Heroes", playerLives);
        g.setColor(Color.black);
        g.drawString(msg, getWidth() - 350, 70);


        Rectangle playButton = new Rectangle(getWidth() - 350, 100, 50, 50);
        Rectangle quitButton = new Rectangle(getWidth() - 350, 180, 50, 50);
        g.drawString("Play", playButton.x + 10, playButton.y + 30);
        g.draw(playButton);
        g.draw(quitButton);
        g.drawString("Quit", quitButton.x + 10, quitButton.y + 30);

    }

    /**
     * draws a restart menu with two rectangle acting as buttons
     *
     * @param g graphics object
     */
    public void restartMenu(Graphics2D g) {

        String msg = String.format("Little Heroes", playerLives);
        g.setColor(Color.black);
        g.drawString(msg, getWidth() - 350, 70);

        String nMsg = String.format("Game Over", playerLives);
        g.setColor(Color.black);
        g.drawString(nMsg, getWidth() - 350, 90);

        Rectangle restartButton = new Rectangle(getWidth() - 350, 100, 50, 50);
        Rectangle quitButton = new Rectangle(getWidth() - 350, 180, 50, 50);
        g.drawString("Restart", restartButton.x + 5, restartButton.y + 30);
        g.draw(restartButton);
        g.draw(quitButton);
        g.drawString("Quit", quitButton.x + 10, quitButton.y + 30);
    }


    /**
     * Draw the current state of the game
     */
    public void draw(Graphics2D g) {

        //draws each layer starting with the blue background and ending with the grass since order of drawing matters
        for (int i = 7; i >= 0; i--) {

            g.drawImage(backGroundImages.get(i), backgroundImageSpeed(backGroundImages.get(i), i * 10), -100, null);

        }

        //draws restart menu if conditions met
        if (!gameState && !menuState) {

            restartState = true;
            restartMenu(g);
            if (endGame) {
                g.drawString("Level 2 Finish Time: " + level2Time + " Seconds", 40, 110);
                g.drawString("Total Time: " + (level2Time + level1Time) + " Seconds", 40, 130);
            }
        }
        //draws menu if conditions met
        if (!gameState && !restartState) {

            drawMenu(g);

        }
        //else draw the game
        else {

            g.drawString("Time: " + startTime, 40, 70);

            int xo = screenWidth / 2 - Math.round(player.getX());
            int yo = screenHeight / 2 - Math.round(player.getY());

            xo = Math.min(xo, 0);
            xo = Math.max(screenWidth - tmap.getPixelWidth(), xo);

            yo = Math.min(yo, 0);
            yo = Math.max(screenHeight - tmap.getPixelHeight(), yo);

            player.setOffsets(xo, yo);
            flag.setOffsets(xo, yo);
            monsterRed.setOffsets(xo, yo);
            purpleMonster.setOffsets(xo, yo);
            silverChest.setOffsets(xo, yo);
            silverKeys.setOffsets(xo, yo);
            goldenKeys.setOffsets(xo, yo);
            goldenChest.setOffsets(xo, yo);

            goldenChest.draw(g);
            silverChest.draw(g);

            flag.draw(g);
            tmap.draw(g, xo, yo);
            monsterRed.draw(g);
            player.draw(g);


            purpleMonster.draw(g);
            silverKeys.draw(g);
            goldenKeys.draw(g);

            //if level 1 and you have the silver key show an indication that you have the silver key
            //would be replaced with a sprite img located at the top left or right side if time permited
            if (silverKeyGained && level == 1) {
                String msg = String.format("You have the Silver Key!");
                g.setColor(Color.darkGray);
                g.drawString(msg, getWidth() - 380, 70);
                //similar to above if
            } else if (goldenKeyGained && level == 2 && endGame == false) {
                String msg = String.format("You have the Golden Key!");
                g.setColor(Color.darkGray);
                g.drawString(msg, getWidth() - 380, 70);
            }
            //if level 2 show the level 1 finish time
            if (level == 2) {
                g.drawString("Level 1 Finish Time: " + level1Time + " Seconds", 40, 90);
            }

            // Show player lives
            String msg = String.format("Player Lives %d", playerLives);
            g.setColor(Color.darkGray);
            g.drawString(msg, getWidth() - 80, 70);
        }


    }

    /**
     * Sets each layer with a parrlax scrolling effect
     *
     * @param backgroundImage background image used
     * @param imageSpeed      image speed for the background image
     * @return returns the scrolling speed
     */
    public int backgroundImageSpeed(Image backgroundImage, int imageSpeed) {

        int scrollingSpeed;
        int offsetX = screenWidth / 2 - Math.round(player.getX()) - tmap.getMapWidth();
        offsetX = Math.min(offsetX, 0);
        offsetX = Math.max(offsetX, screenWidth - tmap.getPixelWidth());

        scrollingSpeed = offsetX * (screenWidth + backgroundImage.getWidth(null)) / (screenWidth * imageSpeed - tmap.getMapWidth());

        return scrollingSpeed;

    }

    /**
     * Update any sprites and check for collisions
     *
     * @param elapsed The elapsed time between this call and the previous call of
     *                elapsed
     */
    public void update(long elapsed) {


        if (gameState) {

            // Make adjustments to the speed of the sprite due to gravity
            if (falling) {
                player.setVelocityY(player.getVelocityY() + (gravity * elapsed));
            }

            //setting initial red monster movement
            if (startGame) {
                startTime = 0;
                monsterRed.setAnimation(redMonsterWalk);
                monsterRed.setVelocityX(-0.1f);
                monsterRed.setVelocityY(0);
                startGame = false;
            }


            silverChest.setAnimationSpeed(1.0f);
            goldenChest.setAnimationSpeed(1.0f);
            monsterRed.setAnimationSpeed(1.0f);
            player.setAnimationSpeed(1.0f);
            silverKeys.setAnimationSpeed(1.00f);
            goldenKeys.setAnimationSpeed(1.00f);
            purpleMonster.setAnimationSpeed(1.0f);

            if (walkingLeft == false && jumping == false && climbing == false && walkingRight == false) {
                player.setAnimation(idleAnim);
            }

            if (walkingLeft) {
                player.setAnimation(walkingAnimLeft);
                player.setVelocityX(-0.10f);
            }
            if (walkingRight) {
                player.setAnimation(walkingAnim);
                player.setVelocityX(0.10f);
            }
            if (jumping) {

                player.setAnimation(jumpingAnim);
                falling = true;
            }
            if (climbing) {
                player.setAnimation(climbingAnim);
                player.setVelocityY(-0.1f);
            }


            if (playerLives == 0) {
                gameState = false;
                menuState = false;
                restartState = true;

            }

            if (hitSpikes) {
                playSound("deathSound.wav");
                player.setX(64);
                player.setY(290);
                player.setVelocityX(0);
                player.setVelocityY(0);
                playerLives--;
                hitSpikes = false;
            }

            // Now update the sprites animation and position
            player.update(elapsed);
            flag.update(elapsed);
            monsterRed.update(elapsed);
            purpleMonster.update(elapsed);
            goldenChest.update(elapsed);
            silverKeys.update(elapsed);
            silverChest.update(elapsed);
            goldenKeys.update(elapsed);


            // Then check for any collisions that may have occurred
            handleFlagCollision();
            handleChestCollision(goldenChest, goldenKeys);
            handleChestCollision(silverChest, silverKeys);
            handleTileMapCollisions(player, elapsed);
            setMonsterAnimation(monsterRed);
            setMonsterAnimation((purpleMonster));
            monsterTileCollision(monsterRed);
            monsterTileCollision(purpleMonster);
            handleMonsterCollision(monsterRed);
            handleMonsterCollision(purpleMonster);
        }
    }

    /**
     * sets the monster animations based on their velocity
     *
     * @param s
     */
    public void setMonsterAnimation(Sprite s) {

        if (s.getVelocityX() > 0) {

            if (s.equals(monsterRed)) {
                s.setAnimation(redMonsterWalkRight);
            } else if (s.equals(purpleMonster)) {

                s.setAnimation(purpleMonsterWalkRight);
            }

        } else if (s.getVelocityX() < 0) {
            if (s.equals(monsterRed)) {
                s.setAnimation(redMonsterWalk);
            } else if (s.equals((purpleMonster))) {

                s.setAnimation(purpleMonsterWalk);
            }
        }
    }

    /**
     * checks if player has collied with a key sprite if so collect the key
     */
    public void handleKeyCollision(Sprite key, Sprite chest) {

        if (boundingBoxCollision(key, player)) {

            if (key.equals(silverKeys)) {
                System.out.println("Silver Key Gained");
                silverKeyGained = true;
                silverChest.pauseAnimationAtFrame(7);
                silverKeys.hide();

            } else if (key.equals(goldenKeys)) {
                goldenKeyGained = true;
                System.out.println("Golden Key Gained");
                goldenChest.pauseAnimationAtFrame(7);
                key.hide();

            }

        }

    }

    /**
     * checks to see if player has collied with check if so show key
     */
    public void handleChestCollision(Sprite chest, Sprite key) {

        if (boundingBoxCollision(chest, player)) {

            if (key.equals(silverKeys) && silverKeyGained == false) {
                silverChest.playAnimation();
                silverKeys.show();
                handleKeyCollision(key, chest);
            }
            if (key.equals(goldenKeys) && goldenKeyGained == false) {
                goldenChest.playAnimation();
                goldenKeys.show();
                handleKeyCollision(key, chest);
            } else
                key.hide();

        }
    }

    /**
     * handles flag collision if player has key and collides with flag then load next level
     */
    public void handleFlagCollision() {

        if (boundingBoxCollision(player, flag) && silverKeyGained && level == 1) {


            tmap.loadMap("maps", "map2.txt");
            level1Time = startTime;
            startTime = 0;
            player.setX(64);
            player.setY(290);
            player.setVelocityX(0);
            player.setVelocityY(0);

            flag.setX(2000);
            flag.setY(290);

            monsterRed.hide();
            silverChest.hide();
            silverKeys.hide();

            purpleMonster.setX(1000);
            purpleMonster.setY(290);
            purpleMonster.setVelocityX(0.1f);
            purpleMonster.setVelocityY(0);
            purpleMonster.show();

            goldenChest.setX(1400);
            goldenChest.setY(290);
            goldenChest.setVelocityX(0);
            goldenChest.setVelocityY(0);
            goldenChest.pauseAnimationAtFrame(1);
            goldenChest.show();

            goldenKeys.setX(1400);
            goldenKeys.setY(290);
            goldenKeys.setVelocityX(0);
            goldenKeys.setVelocityY(0);
            goldenKeys.hide();
            level++;
        }
        if (boundingBoxCollision(player, flag) && goldenKeyGained && level == 2) {
            gameState = false;
            menuState = false;
            level2Time = startTime;
            endGame = true;
            restartState = true;

        }
    }

    /**
     * handles monster collision if player hit by monster
     * send player back to spawn with 1 less life
     *
     * @param s
     */
    public void handleMonsterCollision(Sprite s) {

        if (boundingBoxCollision(player, s) && s.isVisible()) {

            if (s.equals(monsterRed)) {
                System.out.println("monster red hit");
                s.setAnimation(redMonsterWalk);
                s.setAnimationSpeed(1.00f);
            } else if (s.equals(purpleMonster)) {
                System.out.println("monster purple hit");
                s.setAnimation(purpleMonsterWalk);
                s.setAnimationSpeed(1.00f);
            }
            //player hit

            playSound("deathSound.wav");

            playerLives--;
            player.setX(64);
            player.setY(290);
        }

    }

    /**
     * Checks and handles collisions with the tile map for the given sprite 's'.
     * Initial functionality is limited...
     *
     * @param s       The Sprite to check collisions for
     * @param elapsed How time has gone by
     * @throws InterruptedException
     */
    public void handleTileMapCollisions(Sprite s, long elapsed) {
        // This method should check actual tile map collisions.

        if (player.getY() + player.getHeight() > tmap.getPixelHeight()) {

            // Put the player back on the map
            player.setY(tmap.getPixelHeight() - player.getHeight());

            // and make them bounce
            player.setVelocityY(-player.getVelocityY() * (0.03f * elapsed));
        }

        if (player.getX() + player.getWidth() > tmap.getPixelWidth()) {
            player.setX(tmap.getPixelWidth() - player.getWidth());
        }


        collision();


    }

    /**
     * handles monster collision with tile map
     *
     * @param s Sprite
     */
    public void monsterTileCollision(Sprite s) {

        // get's the top right tile
        int tileTopRight = (int) (s.getX() / tmap.getTileWidth());
        //gets the bottom right tile
        int tileBottomRight = tileTopRight + 1;

        // gets the top left tile
        int tileTopLeft = (int) ((s.getY() + s.getHeight()) / tmap.getTileHeight());
        //gets the bottom left tile
        int tileBottomLeft = tileTopLeft - 1;


        if (tmap.getTileChar(tileTopRight, tileTopLeft) == 'n' || tmap.getTileChar(tileBottomRight, tileTopLeft) == 'n'
                || tmap.getTileChar(tileTopRight, tileBottomLeft) == 'n') {

            s.setVelocityX(0.05f);

        }
        if (tmap.getTileChar(tileTopRight, tileTopLeft) == 'm' || tmap.getTileChar(tileBottomRight, tileTopLeft) == 'm'
                || tmap.getTileChar(tileTopRight, tileBottomLeft) == 'm') {

            s.setVelocityX(-0.05f);

        }
    }

    /**
     * handles player collision with the tile map
     */
    public void collision() {

        // get's the top right tile
        int tileTopRight = (int) (player.getX() / tmap.getTileWidth());
        //gets the bottom right tile
        int tileBottomRight = tileTopRight + 1;

        // gets the top left tile
        int tileTopLeft = (int) ((player.getY() + player.getHeight()) / tmap.getTileHeight());

        //gets the bottom left tile
        int tileBottomLeft = tileTopLeft - 1;

        if (tmap.getTileChar(tileTopRight, tileTopLeft) == 'g'
                || tmap.getTileChar(tileBottomRight, tileTopLeft) == 'g') {

            // when the sprite falls the edge of a block this will make the
            // sprite fall slower
            if (player.getVelocityY() > 0) {
                player.setVelocityY(0);
            }

        }

        if (tmap.getTileChar(tileTopRight, tileTopLeft) != 'g'
                || tmap.getTileChar(tileBottomRight, tileTopLeft) != 'g') {

            falling = true;
            canJump = false;

        }

        // checks the bottom right area of everyblock that is not an empty space
        if (tmap.getTileChar(tileTopRight, tileBottomLeft) == 'g') {
            player.setX((float) (tileTopRight * tmap.getTileWidth()) + player.getWidth());
            canJump = true;
            falling = false;
        }

        if (tmap.getTileChar(tileBottomRight, tileBottomLeft) == 'g') {
            player.setX((float) (tileBottomRight * tmap.getTileWidth()) - player.getWidth());
        }

        if (tmap.getTileChar(tileTopRight, tileBottomLeft) == 'g'
                || tmap.getTileChar(tileTopRight, tileTopLeft) == 'g') {
            canJump = true;
            falling = false;
        }

        if (tmap.getTileChar(tileTopRight, tileBottomLeft) == 'w' || tmap.getTileChar(tileTopRight, tileTopLeft) == 'w'
                || tmap.getTileChar(tileBottomRight, tileBottomLeft) == 'w') {
            canClimb = true;


        }
        if (tmap.getTileChar(tileTopRight, tileBottomLeft) == 's' || tmap.getTileChar(tileTopRight, tileTopLeft) == 's'
                || tmap.getTileChar(tileBottomRight, tileBottomLeft) == 's') {

            canClimb = false;
            climbing = false;
            player.setVelocityY(0);
        }

        if (tmap.getTileChar(tileTopRight, tileBottomLeft) == 'b' || tmap.getTileChar(tileTopRight, tileTopLeft) == 'b'
                || tmap.getTileChar(tileBottomRight, tileBottomLeft) == 'b') {
            hitSpikes = true;
        }

    }

    /**
     * Override of the keyPressed event defined in GameCore to catch our own
     * events
     *
     * @param e The event that has been generated
     */
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_ESCAPE) {
            stop();
        }

        if (key == KeyEvent.VK_UP) {
            jump();
        }

        if (key == KeyEvent.VK_RIGHT) {
            walkingRight = true;

        }
        if (key == KeyEvent.VK_LEFT) {

            walkingLeft = true;
        }
        if (key == KeyEvent.VK_E)
            if (canClimb) {
                climbing = true;
            } else climbing = false;


    }

    /**
     * method that allows player to jump
     */
    public void jump() {

        if (canJump) {
            jumping = true;
            player.setVelocityY(-0.10f);
            canJump = false;
        }
    }

    /**
     * bounding box collision checks if 1 sprite collides with another
     *
     * @param s1 Sprite 1
     * @param s2 Sprite 2
     * @return
     */
    public boolean boundingBoxCollision(Sprite s1, Sprite s2) {
        return ((s1.getX() + s1.getImage().getWidth(null) > s2.getX())
                && (s1.getX() < (s2.getX() + s2.getImage().getWidth(null)))
                && ((s1.getY() + s1.getImage().getHeight(null) > s2.getY())
                && (s1.getY() < s2.getY() + s2.getImage().getHeight(null))));
    }

    /**
     * checks to see if a key has been released
     *
     * @param e
     */
    public void keyReleased(KeyEvent e) {

        int key = e.getKeyCode();

        // Switch statement instead of lots of ifs...
        // Need to use break to prevent fall through.
        switch (key) {
            case KeyEvent.VK_ESCAPE:
                stop();
                break;
            case KeyEvent.VK_UP:
                canJump = false;
                jumping = false;
                player.setAnimation(idleAnim);
                break;
            case KeyEvent.VK_RIGHT:
                player.setVelocityX(0.0f);
                walkingRight = false;
                player.setAnimation(idleAnim);
                break;
            case KeyEvent.VK_LEFT:
                player.setVelocityX(0.0f);
                walkingLeft = false;
                player.setAnimation(idleAnim);
                break;
            case KeyEvent.VK_E:
                climbing = false;
                player.setAnimation(idleAnim);
                break;


            default:
                break;
        }
    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    /**
     * method for handling mouse pressed
     * checks if menu option as been selected
     *
     * @param e
     */
    @Override
    public void mousePressed(MouseEvent e) {

        int mouseX = e.getX();
        int mouseY = e.getY();

        if (menuState) {

            //check if mouse click within the play button rectangle if so start the game
            if (mouseX >= getWidth() - 350 && mouseX <= getWidth() - 350 + 50) {

                if (mouseY >= 100 && mouseY <= 150) {
                    gameState = true;

                    menuState = false;

                }
            }
            //checks if mouse click within the quit button rectangle if so quit the game
            if (mouseX >= getWidth() - 350 && mouseX <= getWidth() - 350 + 50) {
                if (mouseY >= 180 && mouseY <= 230) {
                    System.exit(0);
                }
            }
        } else if (restartState) {

            //check if mouse click within the play button rectangle if so start the game
            if (mouseX >= getWidth() - 350 && mouseX <= getWidth() - 350 + 50) {

                if (mouseY >= 100 && mouseY <= 150) {


                    try {
                        restartGame();
                    } catch (Exception ex) {
                        System.out.println(ex);

                    }


                }
            }
            //checks if mouse click within the quit button rectangle if so quit the game
            if (mouseX >= getWidth() - 350 && mouseX <= getWidth() - 350 + 50) {
                if (mouseY >= 180 && mouseY <= 230) {
                    System.exit(0);
                }
            }

        }


    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub

    }

}
